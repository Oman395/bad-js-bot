const Discord = require('discord.js');
const fs = require('fs');
const Memer = require("random-jokes-api");
const token = require('./token.json');
const posts = require('./getcontent.js');
const client = new Discord.Client();
const snoowrap = require('snoowrap');
const { SSL_OP_EPHEMERAL_RSA } = require('constants');
const { time } = require('console');
const { Submission } = require('snoowrap');
const { fromJSON } = require('tough-cookie');
const r = new snoowrap({
    userAgent: token.userAgent,
    clientId: token.clientId,
    clientSecret: token.clientSecret,
    username: token.username,
    password: token.password
});